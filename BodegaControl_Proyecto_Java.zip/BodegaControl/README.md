# BodegaControl - Entrega 1 (UPN)

Prototipo de consola en **Java 17+**, desarrollado para el curso Técnicas de Programación Orientada a Objetos. Permite registrar productos, administrar inventario y registrar ventas para una bodega de barrio.

## Requisitos
- JDK 17 o superior, con `java` y `javac` en el PATH.
- No requiere bibliotecas ni bases de datos externas.

## Compilar y ejecutar
Desde la carpeta raiz del repositorio:

**Windows (PowerShell o CMD):**
```bat
mkdir out
javac -encoding UTF-8 -d out src\bodegacontrol\*.java
java -cp out bodegacontrol.Main
```

**Linux/macOS:**
```bash
mkdir -p out
javac -encoding UTF-8 -d out src/bodegacontrol/*.java
java -cp out bodegacontrol.Main
```

## Demostración reproducible
```bash
java -cp out bodegacontrol.Main --demo
```

## Ejecutar pruebas automáticas
En Windows:
```bat
javac -encoding UTF-8 -d out src\bodegacontrol\*.java test\bodegacontrol\*.java
java -cp out bodegacontrol.PruebasBodegaControl
```
En Linux/macOS:
```bash
javac -encoding UTF-8 -d out src/bodegacontrol/*.java test/bodegacontrol/*.java
java -cp out bodegacontrol.PruebasBodegaControl
```

## Funciones implementadas
- Registrar producto con código único, nombre, precio y stock inicial.
- Consultar y buscar productos por código; buscar por nombre desde la clase de servicio.
- Reponer stock y actualizar precios.
- Registrar ventas con validación de existencia y total.
- Listar productos con pocas existencias (umbral 5 en menú).
- Mostrar ventas y total vendido.
- Controlar entradas incorrectas con excepciones.

## Conceptos de POO
- `Producto`, `Venta`, `Inventario` y `Main`: clases, objetos y métodos.
- Encapsulamiento de atributos y validaciones en `Producto`.
- **Sobrecarga** de `Inventario.agregarProducto(Producto)` y `Inventario.agregarProducto(String, String, double, int)`; también `listarProductos()` y `listarProductos(int)`.
- **Colecciones** `ArrayList<Producto>` y `ArrayList<Venta>`.
- **Excepciones** `IllegalArgumentException` y `IllegalStateException`, gestionadas en el menú.

## Estructura
```
BodegaControl/
  src/bodegacontrol/        Codigo Java
  test/bodegacontrol/       Pruebas ejecutables
  evidencias/               Imagen de la demostracion; agregar capturas propias
  informe/                  Texto base para personalizar el informe
  README.md
  .gitignore
```

## Límites actuales
Datos solo en memoria: se pierden al cerrar. No hay base de datos, login, boletas SUNAT ni pagos en línea. Estas funciones se proponen como mejoras futuras.

## GitHub / integridad académica
Este proyecto fue preparado como **trabajo individual**. El estudiante ha confirmado que el docente permite la modalidad individual (aunque la rúbrica original solicita un equipo). El usuario debe crear su propio repositorio, subir los archivos y **realizar commits reales**. No se incluyen capturas inventadas de colaboradores.

URL del repositorio: **[PEGAR ENLACE REAL AQUI]**.
