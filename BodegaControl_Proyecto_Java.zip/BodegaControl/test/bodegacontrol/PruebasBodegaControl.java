package bodegacontrol;

/** Pruebas sin frameworks externos: ejecutables con Java 17+. */
public class PruebasBodegaControl {
    private static int superadas = 0;

    private static void verificar(boolean condicion, String mensaje) {
        if (!condicion) { throw new AssertionError(mensaje); }
        superadas++;
    }

    private static void esperarError(Runnable operacion, String mensaje) {
        boolean huboError = false;
        try { operacion.run(); }
        catch (IllegalArgumentException | IllegalStateException ex) { huboError = true; }
        verificar(huboError, mensaje);
    }

    public static void main(String[] args) {
        Inventario inv = new Inventario();
        inv.agregarProducto("A1", "Arroz", 5.00, 10);
        inv.agregarProducto(new Producto("L1", "Leche", 4.20, 2));
        verificar(inv.listarProductos().size() == 2, "Alta y sobrecarga");
        verificar(inv.buscarProducto("a1") != null, "Busqueda sin distincion de mayusculas");
        verificar(inv.buscarPorNombre("lec").size() == 1, "Busqueda por nombre");
        esperarError(() -> inv.agregarProducto("A1", "Otro", 6, 1), "Codigos duplicados");
        esperarError(() -> inv.agregarProducto("X", "Mal", -2, 1), "Precio negativo");
        Venta v = inv.registrarVenta("A1", 3);
        verificar(v.getTotal() == 15.0, "Total de venta");
        verificar(inv.buscarProducto("A1").getStock() == 7, "Descuento de stock");
        esperarError(() -> inv.registrarVenta("L1", 10), "Stock insuficiente");
        verificar(inv.buscarProducto("L1").getStock() == 2, "Venta fallida no cambia stock");
        verificar(inv.listarVentas().size() == 1, "Venta fallida no se registra");
        inv.reponerStock("L1", 4);
        verificar(inv.buscarProducto("L1").getStock() == 6, "Reposicion");
        inv.actualizarPrecio("L1", 5.5);
        verificar(inv.buscarProducto("L1").getPrecio() == 5.5, "Cambio de precio");
        verificar(inv.listarProductos(6).size() == 1, "Filtro de stock bajo");
        esperarError(() -> inv.reponerStock("L1", 0), "No permitir reposicion cero");
        verificar(inv.calcularTotalVendido() == 15.0, "Total acumulado");
        System.out.println("PRUEBAS SUPERADAS: " + superadas + "/" + superadas);
    }
}
