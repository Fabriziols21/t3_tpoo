# Evidencias solicitadas

1. `01-demostracion.png` contiene salida REAL de `java -cp out bodegacontrol.Main --demo` ejecutada en el entorno de desarrollo de este paquete. Puede usarse para describir el prototipo, pero se recomienda tomar capturas propias ejecutando el código en VS Code o CMD.
2. Agrega una captura del menú interactivo funcionando en tu equipo.
3. Agrega una captura de la pestaña **Commits** de tu repositorio real y otra de la vista de archivos.
4. Como el docente autorizó la modalidad individual, muestra únicamente tus aportes reales. No simules otros autores.
5. Actualiza el enlace de GitHub en `informe/INFORME_BASE.md` y en el PDF final.
