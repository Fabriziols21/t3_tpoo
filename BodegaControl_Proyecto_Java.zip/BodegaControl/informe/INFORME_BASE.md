# BodegaControl - Informe de la Entrega 1

**Curso:** Técnicas de Programación Orientada a Objetos (UPN)  
**Proyecto:** Sistema de Gestión de Inventario para una Bodega (BodegaControl)  
**Estudiante:** [NOMBRE COMPLETO]  
**Docente:** [NOMBRE DEL DOCENTE]  
**Modalidad:** Individual, autorizada por el docente  
**Fecha:** 12 de noviembre de 2026  
**GitHub:** [ENLACE REAL DEL REPOSITORIO - PENDIENTE]

## 1. Descripción del problema

Las bodegas de barrio administran un catálogo de productos de consumo diario y deben conocer sus existencias para atender ventas. Cuando se utiliza únicamente un cuaderno, una hoja de cálculo sin validaciones o el recuento visual, se pueden producir errores al anotar entradas, salidas, precios y reposiciones. Como consecuencia, el stock que se cree disponible puede diferir del real, generando retrasos al atender clientes, ventas fallidas y compras mal planificadas.

El caso de estudio se sitúa en una bodega familiar de Lima Metropolitana, con un propietario que también atiende la caja y recibe mercadería. Los usuarios previstos son el propietario/administrador y el personal que realiza ventas. El problema específico planteado es **la dificultad para mantener actualizado el inventario después de cada operación**. No se ha afirmado una entrevista o medición real: la bodega es un escenario representativo que deberá contextualizarse con una observación directa si el docente lo exige.

Las consecuencias plausibles incluyen duplicidad de registros, productos agotados no detectados, tiempo adicional buscando artículos y dificultades para estimar el monto de ventas.

## 2. Análisis de causas

Se utiliza un diagrama de Ishikawa de elaboración propia con seis categorías: Personas (capacitación limitada y errores al escribir), Procesos (ventas o reposiciones no registradas), Tecnología (ausencia de una aplicación sencilla), Información (códigos y actualizaciones inconsistentes), Control (conteos escasos y falta de alertas), y Gestión (compras sin datos suficientes). Las causas son hipótesis de trabajo que deberían contrastarse con el responsable de una bodega.

![Diagrama de Ishikawa](diagrama_ishikawa.png)

## 3. Antecedentes

**Antecedente 1: Contexto nacional.** El Ministerio de la Producción (2026) señala que las micro y pequeñas empresas constituyen el 99,2 % de empresas formales en Perú, y que el comercio representa el 44,1 % de las MYPE. Estos datos permiten delimitar la relevancia de atender comercios pequeños; no prueban, por sí solos, que todas las bodegas registren inventarios manualmente.

**Antecedente 2: Gestión de inventarios.** IBM (s. f.) explica que una gestión de inventarios busca conocer dónde se encuentran los productos, cuándo reponerlos y en qué cantidades, así como minimizar faltantes y excesos. La propuesta recoge la necesidad de visibilidad de existencias y actualizaciones tras cada venta.

**Antecedente 3: Herramientas para pequeñas empresas.** Teli (2026) expone que un sistema de inventarios para pequeñas empresas permite realizar seguimiento de stock y reducir errores de procesos manuales. El prototipo adapta esa idea a una implementación educativa en Java por consola.

## 4. Objetivos del proyecto

**Objetivo general:** Desarrollar un prototipo de aplicación en Java orientado a objetos que facilite el registro y la consulta del inventario y de las ventas de una bodega pequeña, con validaciones que reduzcan inconsistencias básicas.

**Objetivos específicos:**
1. Implementar el registro de productos con código único, nombre, precio positivo y cantidad no negativa.
2. Permitir la búsqueda de productos por código y la consulta del inventario disponible.
3. Registrar ventas de productos y descontar las unidades vendidas solo si existe stock suficiente.
4. Presentar productos con stock de cinco unidades o menos y permitir su reposición.
5. Verificar las operaciones principales mediante al menos diez pruebas automáticas.

## 5. Alcance de la solución

**Incluye:** menú de consola, alta de productos, búsqueda, listado, cambio de precios, reposición, venta simple de un solo producto, revisión de stock bajo, historial y total de ventas durante la sesión.

**No incluye en esta entrega:** almacenamiento persistente, interfaz gráfica, autenticación, multiusuario, lector de códigos de barras, documentos tributarios, integración con SUNAT, ventas de varios artículos en un solo comprobante y pagos digitales.

## 6. Descripción de la solución propuesta

**Nombre:** BodegaControl. **Usuarios:** propietario y personal de atención. **Tecnología:** Java 17 o superior sin dependencias externas. **Beneficios esperados:** operaciones más ordenadas, validación de datos, consulta rápida y prevención de ventas de unidades inexistentes. Estos beneficios son objetivos esperados y no resultados medidos en una bodega real.

**Flujo de uso:** Iniciar programa → registrar productos → consultar / buscar → reponer o vender → comprobar nuevo stock → consultar ventas → salir.

## 7. Prototipo inicial en Java

**Clases:** `Producto` (atributos, validación y movimientos de stock); `Inventario` (colecciones y operaciones); `Venta` (registro y cálculo de importe); `Main` (menú y captura de excepciones); `PruebasBodegaControl` (15 verificaciones automáticas).

**Conceptos aplicados:** clases y objetos; métodos; sobrecarga de `agregarProducto(Producto)` y `agregarProducto(String, String, double, int)` y también `listarProductos()` / `listarProductos(int)`; `ArrayList<Producto>` y `ArrayList<Venta>`; excepciones controladas.

**Compilación y ejecución (Windows):**
```bat
mkdir out
javac -encoding UTF-8 -d out src\bodegacontrol\*.java test\bodegacontrol\*.java
java -cp out bodegacontrol.Main
java -cp out bodegacontrol.Main --demo
java -cp out bodegacontrol.PruebasBodegaControl
```

**Pruebas efectuadas en el entorno de generación:** compilación correcta con JDK 21; resultado `PRUEBAS SUPERADAS: 15/15`. La demostración muestra alta de tres productos, búsqueda de P002, venta de dos unidades por S/ 8.40, stock actualizado de 6 a 4, productos con bajo stock y error controlado ante una venta mayor a la existencia.

![Salida verificada de la JVM](../evidencias/01-demostracion.png)

## 8. Evidencias de trabajo individual y GitHub

**URL del repositorio:** [ENLACE REAL DEL REPOSITORIO - PENDIENTE].

El desarrollo corresponde a una sola persona, y la rúbrica solicita commits de todos los integrantes. El estudiante ha confirmado que el docente autorizó la entrega individual. Las siguientes capturas deben incluirse antes de entregar: repositorio público o compartido accesible, historial de commits del estudiante, vista de archivos `src/`, ejecución desde su equipo y, de ser necesario, constancia de autorización de modalidad individual. **No se han inventado usuarios, commits ni capturas de GitHub.**

**Ejemplo de secuencia de commits futuros, solo si se realizan realmente:** `feat: crear entidades Producto y Venta`; `feat: implementar Inventario y validaciones`; `feat: integrar menu y pruebas`; `docs: agregar informe y evidencias`.

## Referencias (APA 7)

IBM. (s. f.). *What is inventory management?* https://www.ibm.com/think/topics/inventory-management

Ministerio de la Producción. (2026, 14 de mayo). *Las MYPE contribuyen con el 20.6 % al PBI y generan 10.3 millones de empleos en el Perú*. https://www.gob.pe/institucion/produce/noticias/1391537-las-mype-contribuyen-con-el-20-6-al-pbi-y-generan-10-3-millones-de-empleos-en-el-peru

Teli, J. (2026, 6 de mayo). *Inventory management systems: A guide for small businesses*. Xero. https://www.xero.com/us/guides/inventory-management-system/

## Lista de verificación previa a la entrega

- [x] Modalidad individual autorizada por el docente (según confirmación del estudiante).
- [ ] Completar nombre, docente y fecha real si cambia.
- [ ] Contextualizar el problema con una bodega observada o entrevistada si se solicita.
- [ ] Crear un repositorio propio y subir el código.
- [ ] Realizar commits auténticos en GitHub y tomar capturas.
- [ ] Sustituir el enlace pendiente en el informe final PDF.
- [ ] Ejecutar el proyecto en mi computadora y capturar las pantallas.
