package bodegacontrol;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Servicio de productos, existencias y ventas en memoria. */
public class Inventario {
    private final List<Producto> productos = new ArrayList<>();
    private final List<Venta> ventas = new ArrayList<>();

    // Sobrecarga 1: recibe un objeto ya construido.
    public void agregarProducto(Producto producto) {
        if (producto == null) {
            throw new IllegalArgumentException("El producto no puede ser nulo.");
        }
        if (buscarProducto(producto.getCodigo()) != null) {
            throw new IllegalArgumentException("Ya existe el codigo " + producto.getCodigo());
        }
        productos.add(producto);
    }

    // Sobrecarga 2: recibe los datos primitivos para construir el objeto.
    public void agregarProducto(String codigo, String nombre, double precio, int stock) {
        agregarProducto(new Producto(codigo, nombre, precio, stock));
    }

    public Producto buscarProducto(String codigo) {
        if (codigo == null) { return null; }
        for (Producto p : productos) {
            if (p.getCodigo().equalsIgnoreCase(codigo.trim())) { return p; }
        }
        return null;
    }

    public List<Producto> buscarPorNombre(String texto) {
        if (texto == null || texto.isBlank()) {
            throw new IllegalArgumentException("Escribe un nombre a buscar.");
        }
        List<Producto> encontrados = new ArrayList<>();
        for (Producto p : productos) {
            if (p.getNombre().toLowerCase(java.util.Locale.ROOT)
                    .contains(texto.toLowerCase(java.util.Locale.ROOT).trim())) {
                encontrados.add(p);
            }
        }
        return encontrados;
    }

    public List<Producto> listarProductos() {
        return Collections.unmodifiableList(productos);
    }

    // Segunda sobrecarga: filtrado opcional por stock bajo.
    public List<Producto> listarProductos(int stockMaximo) {
        if (stockMaximo < 0) {
            throw new IllegalArgumentException("El umbral de stock no puede ser negativo.");
        }
        List<Producto> encontrados = new ArrayList<>();
        for (Producto p : productos) {
            if (p.getStock() <= stockMaximo) { encontrados.add(p); }
        }
        return encontrados;
    }

    private Producto exigirProducto(String codigo) {
        Producto producto = buscarProducto(codigo);
        if (producto == null) {
            throw new IllegalArgumentException("No existe un producto con codigo " + codigo);
        }
        return producto;
    }

    public void reponerStock(String codigo, int cantidad) {
        exigirProducto(codigo).aumentarStock(cantidad);
    }

    public void actualizarPrecio(String codigo, double precio) {
        exigirProducto(codigo).setPrecio(precio);
    }

    public Venta registrarVenta(String codigo, int cantidad) {
        Producto p = exigirProducto(codigo);
        // Primero se validan todos los datos; no se registra la venta si falla.
        if (cantidad <= 0 || cantidad > p.getStock()) {
            throw new IllegalArgumentException("Cantidad invalida o stock insuficiente (disponible: "
                + p.getStock() + ").");
        }
        Venta venta = new Venta(p, cantidad);
        p.descontarStock(cantidad);
        ventas.add(venta);
        return venta;
    }

    public List<Venta> listarVentas() {
        return Collections.unmodifiableList(ventas);
    }

    public double calcularTotalVendido() {
        double total = 0;
        for (Venta v : ventas) { total += v.getTotal(); }
        return total;
    }
}
