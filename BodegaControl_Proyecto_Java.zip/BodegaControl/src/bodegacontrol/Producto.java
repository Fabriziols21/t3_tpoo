package bodegacontrol;

import java.util.Locale;

/** Entidad que representa un producto comercializado por la bodega. */
public class Producto {
    private final String codigo;
    private String nombre;
    private double precio;
    private int stock;

    public Producto(String codigo, String nombre, double precio, int stock) {
        if (codigo == null || codigo.isBlank()) {
            throw new IllegalArgumentException("El codigo no puede estar vacio.");
        }
        this.codigo = codigo.trim().toUpperCase(Locale.ROOT);
        setNombre(nombre);
        setPrecio(precio);
        if (stock < 0) {
            throw new IllegalArgumentException("El stock no puede ser negativo.");
        }
        this.stock = stock;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }
    public int getStock() { return stock; }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre no puede estar vacio.");
        }
        this.nombre = nombre.trim();
    }

    public void setPrecio(double precio) {
        if (!Double.isFinite(precio) || precio <= 0) {
            throw new IllegalArgumentException("El precio debe ser mayor que cero.");
        }
        this.precio = precio;
    }

    public void aumentarStock(int cantidad) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad a reponer debe ser positiva.");
        }
        this.stock = Math.addExact(this.stock, cantidad);
    }

    public void descontarStock(int cantidad) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad vendida debe ser positiva.");
        }
        if (cantidad > stock) {
            throw new IllegalStateException("Stock insuficiente. Disponible: " + stock);
        }
        stock -= cantidad;
    }

    @Override
    public String toString() {
        return String.format(Locale.US,
            "%-6s | %-22s | S/ %7.2f | Stock: %3d", codigo, nombre, precio, stock);
    }
}
