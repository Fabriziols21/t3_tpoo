package bodegacontrol;

import java.util.List;
import java.util.Locale;
import java.util.Scanner;

/** Programa de consola. Ejecutar con --demo para una demostracion reproducible. */
public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final Inventario inventario = new Inventario();

    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("--demo")) {
            ejecutarDemo();
            return;
        }
        ejecutarMenu();
    }

    private static void ejecutarMenu() {
        System.out.println("=====================================");
        System.out.println("  BODEGACONTROL - INVENTARIO EN JAVA  ");
        System.out.println("=====================================");
        while (true) {
            System.out.println("\n1. Registrar producto");
            System.out.println("2. Ver inventario");
            System.out.println("3. Buscar producto");
            System.out.println("4. Reponer stock");
            System.out.println("5. Registrar venta");
            System.out.println("6. Ver productos con stock bajo");
            System.out.println("7. Ver ventas y total");
            System.out.println("8. Actualizar precio");
            System.out.println("0. Salir");
            String opcion = leerTexto("Elige una opcion: ");
            try {
                switch (opcion) {
                    case "1" -> registrarProducto();
                    case "2" -> imprimirProductos(inventario.listarProductos());
                    case "3" -> buscarProducto();
                    case "4" -> reponerStock();
                    case "5" -> vender();
                    case "6" -> imprimirProductos(inventario.listarProductos(5));
                    case "7" -> imprimirVentas();
                    case "8" -> actualizarPrecio();
                    case "0" -> { System.out.println("Hasta luego."); return; }
                    default -> System.out.println("Opcion no reconocida.");
                }
            } catch (IllegalArgumentException | IllegalStateException | ArithmeticException ex) {
                System.out.println("ERROR: " + ex.getMessage());
            }
        }
    }

    private static String leerTexto(String pregunta) {
        System.out.print(pregunta);
        return scanner.nextLine().trim();
    }

    private static int leerEntero(String pregunta) {
        try {
            return Integer.parseInt(leerTexto(pregunta));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Ingresa un numero entero valido.");
        }
    }

    private static double leerDecimal(String pregunta) {
        try {
            return Double.parseDouble(leerTexto(pregunta).replace(',', '.'));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Ingresa un precio numerico valido.");
        }
    }

    private static void registrarProducto() {
        String codigo = leerTexto("Codigo: ");
        String nombre = leerTexto("Nombre: ");
        double precio = leerDecimal("Precio (S/): ");
        int stock = leerEntero("Cantidad inicial: ");
        inventario.agregarProducto(codigo, nombre, precio, stock);
        System.out.println("Producto registrado correctamente.");
    }

    private static void buscarProducto() {
        String busqueda = leerTexto("Codigo del producto: ");
        Producto p = inventario.buscarProducto(busqueda);
        System.out.println(p == null ? "No se encontro el producto." : p);
    }

    private static void reponerStock() {
        String codigo = leerTexto("Codigo: ");
        int cantidad = leerEntero("Unidades a reponer: ");
        inventario.reponerStock(codigo, cantidad);
        System.out.println("Stock actualizado.");
    }

    private static void vender() {
        String codigo = leerTexto("Codigo del producto: ");
        int cantidad = leerEntero("Unidades a vender: ");
        Venta venta = inventario.registrarVenta(codigo, cantidad);
        System.out.println("Venta exitosa. " + venta);
    }

    private static void actualizarPrecio() {
        String codigo = leerTexto("Codigo: ");
        double precio = leerDecimal("Nuevo precio (S/): ");
        inventario.actualizarPrecio(codigo, precio);
        System.out.println("Precio actualizado.");
    }

    private static void imprimirProductos(List<Producto> productos) {
        if (productos.isEmpty()) {
            System.out.println("No hay productos para mostrar.");
            return;
        }
        System.out.println("CODIGO | NOMBRE                 | PRECIO     | EXISTENCIAS");
        for (Producto p : productos) { System.out.println(p); }
    }

    private static void imprimirVentas() {
        if (inventario.listarVentas().isEmpty()) {
            System.out.println("Aun no se registran ventas.");
        }
        for (Venta v : inventario.listarVentas()) { System.out.println(v); }
        System.out.printf(Locale.US, "Total vendido: S/ %.2f%n", inventario.calcularTotalVendido());
    }

    private static void ejecutarDemo() {
        System.out.println("BODEGACONTROL | DEMOSTRACION AUTOMATICA");
        System.out.println("---------------------------------------");
        inventario.agregarProducto("P001", "Arroz 1 kg", 4.80, 12);
        inventario.agregarProducto(new Producto("P002", "Leche evaporada", 4.20, 6));
        inventario.agregarProducto("P003", "Aceite 1 L", 9.50, 3);
        System.out.println("[OK] Tres productos registrados usando ambas sobrecargas.");
        imprimirProductos(inventario.listarProductos());
        System.out.println("\nBusqueda P002 -> " + inventario.buscarProducto("P002").getNombre());
        System.out.println("Venta P002 x 2: S/ " + String.format(Locale.US, "%.2f",
            inventario.registrarVenta("P002", 2).getTotal()));
        System.out.println("Stock P002 restante: " + inventario.buscarProducto("P002").getStock());
        System.out.println("\nProductos con stock <= 5:");
        imprimirProductos(inventario.listarProductos(5));
        try {
            inventario.registrarVenta("P003", 99);
        } catch (IllegalArgumentException ex) {
            System.out.println("[EXCEPCION CONTROLADA] " + ex.getMessage());
        }
        System.out.printf(Locale.US, "Total vendido: S/ %.2f%n", inventario.calcularTotalVendido());
        System.out.println("[FIN] Demostracion completada correctamente.");
    }
}
