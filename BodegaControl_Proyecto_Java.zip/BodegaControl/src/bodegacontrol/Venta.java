package bodegacontrol;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Registro inmutable de una venta de un producto. */
public class Venta {
    private final String codigoProducto;
    private final String nombreProducto;
    private final int cantidad;
    private final double precioUnitario;
    private final LocalDateTime fecha;

    public Venta(Producto producto, int cantidad) {
        if (producto == null || cantidad <= 0) {
            throw new IllegalArgumentException("Los datos de venta no son validos.");
        }
        this.codigoProducto = producto.getCodigo();
        this.nombreProducto = producto.getNombre();
        this.precioUnitario = producto.getPrecio();
        this.cantidad = cantidad;
        this.fecha = LocalDateTime.now();
    }

    public double getTotal() { return precioUnitario * cantidad; }
    public int getCantidad() { return cantidad; }
    public String getCodigoProducto() { return codigoProducto; }

    @Override
    public String toString() {
        return String.format(Locale.US, "%s | %s - %s | %d unid. | Total: S/ %.2f",
            fecha.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")),
            codigoProducto, nombreProducto, cantidad, getTotal());
    }
}
